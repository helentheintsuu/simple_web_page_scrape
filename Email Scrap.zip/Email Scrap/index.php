<!-- <form method="POST">

</form>


<label for=“git_email">Email address</label>
<input type="email" class="form-control" id=“git_email"  name=“git_email"  placeholder="Enter email">
</div>
<div class="form-group">
<label for=“git_pwd">Password</label>
<input type="password" class="form-control" id="git_pwd" name="git_pwd" placeholder="Password">
</div>  <button type="submit" class="btn btn-primary">Submit</button>   	
</form>
 -->
<!doctype html>  
<html>  
<head>  
<title>Login</title>  
    <style>   
        body{  
              
    margin-top: 100px;  
    margin-bottom: 100px;  
    margin-right: 150px;  
    margin-left: 80px;  
    background-color: azure ;  
    color: palevioletred;  
    font-family: verdana;  
    font-size: 100%  
      
        }  
            h1 {  
    color: indigo;  
    font-family: verdana;  
    font-size: 100%;  
}  
        h3 {  
    color: indigo;  
    font-family: verdana;  
    font-size: 100%;  
} </style>  
</head>  
<body>  
     <center><h1>Eash Scrap Text from Web Page</h1></center>  
   
<h3>Login Form</h3>  
<form method="post" name="scrap_form" id="scrap_form" action="scrapetext.php">   
<!-- <form method="post" name="scrap_form" id="scrap_form" action="scrape.php">    for all web page scrape from web page -->
	<label>Enter Website URL To Scrape Data</label>	
	<input type="input" name="website_url" id="website_url"> 
	<input type="submit" name="submit" value="Submit" > 
	<div class=“form-group">
</body>  
</html>   