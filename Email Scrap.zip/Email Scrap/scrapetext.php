<?php

if(isset($_POST['submit'])){
	 list($month, $website_url ) = explode("@", $_POST['website_url']);
  
  	if($website_url!= ""){

  		
  		$website_url_link = 'https://'.$website_url;
  	
  		scrapeWebsiteData($website_url_link);


  	}

}

function scrapeWebsiteData($website_url){

include('simple_html_dom.php');

$html = file_get_html('https://isecom.org');

echo $html -> find('title', 0)-> plaintext;

echo "<br>";
echo "<br>";



echo "for paragraph";
$list_array_paragraph = $html-> find('p');
for($i = 0; $i < sizeOf($list_array_paragraph); $i++){
	echo $list_array_paragraph[$i];
	echo "<br>";
}

echo "for header with span text";
$list_array_span = $html-> find('span');
for($i = 0; $i < sizeOf($list_array_span); $i++){
	echo $list_array_span[$i];
	echo "<br>";
}

echo "for header ";
$list_array_h2 = $html-> find('h2');
for($i = 0; $i < sizeOf($list_array_h2); $i++){
	echo $list_array_h2[$i];
	echo "<br>";
}

$list_array_h4 = $html-> find('h4');
for($i = 0; $i < sizeOf($list_array_h4); $i++){
	echo $list_array_h4[$i];
	echo "<br>";
}


// for($i = 0; $i < sizeOf($list_array_button); $i++){
// 	echo $list_array_button[$i];
// 	echo "<br>";
// }

echo "for link";
$list_array = $html-> find('a');
for($i = 0; $i < sizeOf($list_array); $i++){
	echo $list_array[$i];
	echo "<br>";
}
}
?>