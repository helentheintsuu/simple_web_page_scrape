<?php

if(isset($_POST['submit'])){
	 list($month, $website_url ) = explode("@", $_POST['website_url']);
  
  	if($website_url!= ""){
  		$website_url = "https://"."$website_url";
		 scrapeWebsiteData($website_url);
		// $start_point = strpos($html, '<h3 class="widgettitle">Latest Posts</h3>');
		// $end_point = strpos($html, '</div>', $start_point);
		// $length = $end_point-$start_point;
		// $html = substr($html, $start_point, $length);
		// echo $html;
	}


}


function scrapeWebsiteData($website_url){
	if (!function_exists('curl_init')) {
		die('cURL is not installed. Please install and try again.');
	}
	$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $website_url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$output = curl_exec($curl);
		curl_close($curl);
		echo $output;
	
	
}
 ?>


